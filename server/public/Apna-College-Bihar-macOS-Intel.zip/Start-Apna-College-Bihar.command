#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
APP="$DIR/Apna College Bihar.app"

echo "=========================================================="
echo "    Starting Apna College Bihar Desktop (macOS)           "
echo "=========================================================="
echo ""
echo "[1/3] Removing Gatekeeper quarantine..."
xattr -cr "$APP" 2>/dev/null || true
xattr -d com.apple.quarantine "$APP" 2>/dev/null || true

echo "[2/3] Setting executable permissions..."
chmod -R 755 "$APP/Contents/MacOS" 2>/dev/null || true
chmod -R 755 "$APP/Contents/Frameworks" 2>/dev/null || true

echo "[3/3] Checking framework symlinks..."
FW="$APP/Contents/Frameworks/Electron Framework.framework"
if [ -d "$FW" ] && [ ! -L "$FW/Electron Framework" ]; then
    rm -f "$FW/Electron Framework" "$FW/Resources" "$FW/Libraries" "$FW/Helpers" 2>/dev/null || true
    rm -f "$FW/Versions/Current" 2>/dev/null || true
    ln -s "A" "$FW/Versions/Current" 2>/dev/null || true
    ln -s "Versions/Current/Electron Framework" "$FW/Electron Framework" 2>/dev/null || true
    ln -s "Versions/Current/Resources" "$FW/Resources" 2>/dev/null || true
    ln -s "Versions/Current/Libraries" "$FW/Libraries" 2>/dev/null || true
    ln -s "Versions/Current/Helpers" "$FW/Helpers" 2>/dev/null || true
fi

echo "Launching application..."
open "$APP"
echo ""
echo "Apna College Bihar launched successfully!"
echo "You can close this window now."
