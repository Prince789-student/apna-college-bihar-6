#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
APP_PATH="$DIR/Apna College Bihar.app"
echo "Starting Apna College Bihar for macOS..."
xattr -cr "$APP_PATH" 2>/dev/null || true
chmod +x "$APP_PATH/Contents/MacOS/Apna College Bihar" 2>/dev/null || true
open "$APP_PATH"
