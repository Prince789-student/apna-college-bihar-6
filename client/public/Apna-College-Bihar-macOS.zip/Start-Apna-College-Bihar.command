#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
APP="$DIR/Apna College Bihar.app"

echo "=========================================================="
echo "    Starting Apna College Bihar Desktop (macOS)           "
echo "=========================================================="
echo ""
echo "[1/3] Removing Gatekeeper quarantine..."
xattr -cr "$APP" 2>/dev/null || true
xattr -d com.apple.quarantine "$APP" 2>/dev/null || true

echo "[2/3] Setting executable permissions..."
chmod -R 755 "$APP/Contents/MacOS" 2>/dev/null || true
chmod -R 755 "$APP/Contents/Frameworks" 2>/dev/null || true

echo "[3/3] Restoring framework symlinks..."
FW_DIR="$APP/Contents/Frameworks"
for f in "Electron Framework" "ReactiveObjC" "Squirrel" "Mantle"; do
    FW="$FW_DIR/$f.framework"
    if [ -d "$FW" ] && [ ! -L "$FW/$f" ]; then
        rm -f "$FW/$f" "$FW/Resources" "$FW/Libraries" "$FW/Helpers" 2>/dev/null || true
        rm -f "$FW/Versions/Current" 2>/dev/null || true
        ln -s "A" "$FW/Versions/Current" 2>/dev/null || true
        ln -s "Versions/Current/$f" "$FW/$f" 2>/dev/null || true
        ln -s "Versions/Current/Resources" "$FW/Resources" 2>/dev/null || true
        if [ "$f" = "Electron Framework" ]; then
            ln -s "Versions/Current/Libraries" "$FW/Libraries" 2>/dev/null || true
            ln -s "Versions/Current/Helpers" "$FW/Helpers" 2>/dev/null || true
        fi
    fi
done

echo "Launching application..."
open "$APP"
echo ""
echo "Apna College Bihar launched successfully!"
echo "You can close this window now."
