#!/bin/bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
chmod +x "$DIR/Apna-College-Bihar" 2>/dev/null || true
chmod +x "$DIR/chrome-sandbox" 2>/dev/null || true
exec "$DIR/Apna-College-Bihar" --no-sandbox "$@"
